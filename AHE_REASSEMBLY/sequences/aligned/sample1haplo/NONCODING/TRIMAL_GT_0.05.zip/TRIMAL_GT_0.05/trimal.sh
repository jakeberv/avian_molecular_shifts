#!/bin/bash
#uses readal to convert formats
FILES=/Users/cotinga/jsb439@cornell.edu/AnchoredEnrichment/bird2020/berv_alignments/unmasked/min2x/qual20_cov2_haplo_bestonly/initial_test_filters/min50bp_min10p_aligned/ALIGNED/NONCODING/TRIMAL_GT_0.05/unknown/*.aln
for file in $FILES 
do
	echo "Trimming " $file " MSA in FASTA format using TrimAl 5% occupancy coverage..."
	/Applications/Phylogenetics/trimal-github_may2020/source/trimal -in $file -out $file -gt 0.05
done