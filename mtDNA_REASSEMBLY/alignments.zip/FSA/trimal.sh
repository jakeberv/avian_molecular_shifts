#!/bin/bash
#uses readal to convert formats
FILES=/Users/cotinga/jsb439@cornell.edu/AnchoredEnrichment/bird2020/berv_alignments/mtdnas/FSA/*.aln
for file in $FILES 
do
	echo "Trimming " $file " MSA in FASTA format using TrimAl 5% occupancy coverage..."
	/Applications/Phylogenetics/trimal-github_may2020/source/trimal -in $file -out $file -gt 0.05
done